package bean;

public class login {
	private String user;
	private String pass;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public boolean checkUser()
	{
		if(user.equals("Raj")&& pass.equals("123"))
			return true;
		else
			return false;
	}

}

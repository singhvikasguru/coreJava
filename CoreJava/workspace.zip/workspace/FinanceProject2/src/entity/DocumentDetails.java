package entity;

import java.sql.Blob;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DocumentDetails {
@Id
private int sNo;
private int applicationNo;
private Blob image;
public int getsNo() {
	return sNo;
}
public void setsNo(int sNo) {
	this.sNo = sNo;
}
public int getApplicationNo() {
	return applicationNo;
}
public void setApplicationNo(int applicationNo) {
	this.applicationNo = applicationNo;
}
public Blob getImage() {
	return image;
}
public void setImage(Blob image) {
	this.image = image;
}
}

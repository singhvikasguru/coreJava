package entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ContactDetails {
@Id
private int sNo;
@ManyToOne
@JoinColumn(name="custId")
RegDetails reg;
private String addressType;
private String address;
public RegDetails getReg() {
	return reg;
}
public void setReg(RegDetails reg) {
	this.reg = reg;
}
public int getsNo() {
	return sNo;
}
public void setsNo(int sNo) {
	this.sNo = sNo;
}
public String getAddressType() {
	return addressType;
}
public void setAddressType(String addressType) {
	this.addressType = addressType;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}


}

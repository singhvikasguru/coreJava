package entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Documents {
@Id
private int sNo;
private String dType;
public int getsNo() {
	return sNo;
}
public void setsNo(int sNo) {
	this.sNo = sNo;
}
public String getdType() {
	return dType;
}
public void setdType(String dType) {
	this.dType = dType;
}


}

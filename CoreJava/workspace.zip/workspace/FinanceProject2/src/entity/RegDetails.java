package entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class RegDetails {
@Id
private int custId;
@OneToMany(mappedBy="reg")
List<ContactDetails> contactList;

private String fName;
private String lName;
private String gender;
private Date dob;
private String pType;
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}

public List<ContactDetails> getContactList() {
	return contactList;
}
public void setContactList(List<ContactDetails> contactList) {
	this.contactList = contactList;
}
public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public String getpType() {
	return pType;
}
public void setpType(String pType) {
	this.pType = pType;
}


}

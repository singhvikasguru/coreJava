package service;

import entity.Loan;
import orm.LoanDao;

public class LoanService {
public void Test(){
	/*Loan l = new Loan();
	l.setSno(1);
	l.setDescription("Hello");
	l.setType("P");*/
	LoanDao lDao= new LoanDao();
	System.out.println("Test Called");
	//lDao.TestTran(l);
}
}

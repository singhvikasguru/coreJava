package co.oracle.ejbclient;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.oracle.ejb.CalculatorRemote;

public class Client {
	public static void main(String[] args) {
		Hashtable<String, String> table=new Hashtable<>();
		table.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
		table.put(Context.PROVIDER_URL, "t3://localhost:7001");
		//table.put(Context.PROVIDER_URL, "t3://localhost:7001");
		table.put(Context.SECURITY_PRINCIPAL, "vikas");
		table.put(Context.SECURITY_CREDENTIALS, "weblogic1");
		
		try {
			Context ctx=new InitialContext(table);
			CalculatorRemote remote=(CalculatorRemote) ctx.lookup("cal#com.oracle.ejb.CalculatorRemote");
			System.out.println("Lookup successful ...");
			float result=remote.add(10, 20);
			System.out.println("Result : "+result);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

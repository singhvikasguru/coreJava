package com.oracle.ejb;

import javax.ejb.Remote;

@Remote
public interface GreetingBeanRemote {
	String sayHello(String name);
}

package com.oracle.ejb;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

@Stateless(mappedName="greet")
public class GreetingBean implements GreetingBeanRemote {

    /**
     * Default constructor. 
     */
    public GreetingBean() {
        // TODO Auto-generated constructor stub
    }
    @Override
    public String sayHello(String name)
    {
    	System.out.println(name+" invoked this method");
    	InetAddress add=null;
    	try {
			add=InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return "Hi --"+name+" --Good --Afternoon, i m coming from --"+add;
    	//return null;
    }

}

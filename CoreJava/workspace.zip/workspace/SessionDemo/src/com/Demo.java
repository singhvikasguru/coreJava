package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import javax.xml.ws.Response;

/**
 * Servlet implementation class Demo
 */
@WebServlet("/Hi")
public class Demo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Demo() {
        super();
        // TODO Auto-generated constructor stub
    }
    int count =0;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		HttpSession hs=request.getSession();
		
		count++;
		pw.println("<br> count value is "+count);
		pw.println("Session id id : "+hs.getId());
		if(hs.isNew())
		{
			pw.println("<br> New Client");
		}
		else
			pw.println("<br>Old Client");
		
		pw.println("<br>Session creation time "+new Date(hs.getCreationTime()));
		pw.println("<br> Default time of Session "+new Date(hs.getMaxInactiveInterval()));
		pw.println("<br> Last session time "+hs.getMaxInactiveInterval());
		hs.setMaxInactiveInterval(600);
		pw.println("<br> changed time of Session "+hs.getMaxInactiveInterval());
		
		if(count%5==0)
		{
			doPost(request, response);
			hs.invalidate();
		}
		Cookie cc=new Cookie("abc : "+count, "xyz : "+count);
		response.setContentType("text/html");
		response.addCookie(cc);
		
		
	}

	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter pw=response.getWriter();
		Cookie cc1[]=request.getCookies();
		for(Cookie c:cc1)
		{
			pw.println("Name of Cookie "+c.getName()+" , Value of Cookies "+c.getValue()+"<br>");
		}
	}

}

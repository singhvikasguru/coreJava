package com.oracle.ejb;

import javax.ejb.Remote;

@Remote
public interface CalculatorRemote {
float add(float a , float b);
float diff(float a, float b);

}

package com.oracle.ejb;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class Calculator
 */
@Stateless(mappedName="cal")
@LocalBean
public class Calculator implements CalculatorRemote {

    
    public Calculator() {
        // TODO Auto-generated constructor stub
    }
    
    public float add(float a, float b)
    {
    	System.out.println("Client invoked add method");
    	return a+b;
    }
    
    public float diff(float a, float b)
    {
    	System.out.println("Client invoked diff method");
    	return a-b;
    }

}

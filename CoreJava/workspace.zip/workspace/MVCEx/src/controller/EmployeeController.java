package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
//import java.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.catalina.servlet4preview.RequestDispatcher;

import entity.Employee;
import service.EmployeeService;

/**
 * Servlet implementation class EmployeeController
 */
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		EmployeeService es=new EmployeeService();
		List<Employee> lst=es.getEmployeeInfo();
		request.setAttribute("EmpInfo", lst);
		//RequestDispatcher rd=request.getRequestDispatcher("EmployeeStore.jsp");
		//rd.include(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		float salary=Float.parseFloat(request.getParameter("salary"));
		Employee emp=new Employee();
		emp.setId(id);
		emp.setName(name);
		emp.setSalary(salary);
		
		EmployeeService es=new EmployeeService();
		String result=es.storeEmployeeInfo(emp);
		System.out.println(result);
		
		RequestDispatcher rd= request.getRequestDispatcher("EmployeeStore.jsp");
		request.setAttribute("key", result);
		doGet(request, response);
		rd.include(request, response);
	}

}

package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.Employee;

public class EmployeeDao {
	EntityManager em;
	public EmployeeDao()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("MVCEx");
		em=emf.createEntityManager();
	}
	
	public String stoteEmployee(Employee emp)
	{
		
		EntityTransaction tran=em.getTransaction();
		tran.begin();
			em.persist(emp);
		tran.commit();
		
		Employee ob=em.find(emp.getClass(), new Integer(emp.getId()));
		if(ob!=null)
		{
			return "Record stored successfully";
		}
		else
			return "Record not stored";
	}
	
	public List<Employee> getEmployeeDetails()
	{
		Query qry=em.createQuery("select emp from Employee emp");
		List<Employee> lst=qry.getResultList();
		return lst;
	}

}

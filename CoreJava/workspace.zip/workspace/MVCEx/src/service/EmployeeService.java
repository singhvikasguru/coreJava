package service;

import java.util.Iterator;
import java.util.List;

import dao.EmployeeDao;

//import javax.persistence.EntityManagerFactory;

import entity.Employee;

public class EmployeeService {
	public String storeEmployeeInfo(Employee emp)
	{
		if(emp.getSalary()>12000)
		{
			EmployeeDao ed=new EmployeeDao();
			return ed.stoteEmployee(emp);
		}
		else
		{
			return "salary must be >12000";
		}
				
	}
	public List<Employee> getEmployeeInfo()
	{
		EmployeeDao ed=new EmployeeDao();
		List<Employee> lst=ed.getEmployeeDetails();
		Iterator<Employee> li=lst.iterator();
		while(li.hasNext())
		{
			Employee emp=li.next();
			emp.setSalary(emp.getSalary()+500);
		}
		return lst;
	}

}

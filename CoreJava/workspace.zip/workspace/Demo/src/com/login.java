package com;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class login {
	@Id
	private String emailId;
	private String pass;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	

}

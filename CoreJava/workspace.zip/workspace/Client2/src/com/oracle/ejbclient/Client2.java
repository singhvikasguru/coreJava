package com.oracle.ejbclient;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.oracle.ejb.GreetingBeanRemote;

public class Client2 {
	public static void main(String[] args) {
		Hashtable<String, String> table=new Hashtable<>();
		table.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
		table.put(Context.PROVIDER_URL, "t3://192.168.0.150:7001");
		//table.put(Context.PROVIDER_URL, "t3://localhost:7001");
		table.put(Context.SECURITY_PRINCIPAL, "shru");
		table.put(Context.SECURITY_CREDENTIALS, "weblogic1");
		
		try {
			Context ctx=new InitialContext(table);
			GreetingBeanRemote remote=(GreetingBeanRemote) ctx.lookup("greet#com.oracle.ejb.GreetingBeanRemote");
			System.out.println("Lookup successful ...");
			String result=remote.sayHello("Vikas");
			System.out.println("Result : "+result);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

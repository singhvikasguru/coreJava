
public class base {
	public static void main(String[] args) {
		base1 b=new derive();
		b.wish();
	}

}
 class base1
 {
	 void wish()
	 {
		 hello();
	 }
	 void hello()
	 {
		 System.out.println(" Base ");
	 }
 }
 class derive extends base1{
	 void wish()
	 {
		 System.out.println("Derive");
	 }
	 
	 }
 

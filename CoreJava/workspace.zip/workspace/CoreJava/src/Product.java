
public class Product {
		private int prdId;
		private String prdName;
		private float price;
		
		public int getPrdId() {
			return prdId;
		}

		public void setPrdId(int prdId) {
			this.prdId = prdId;
		}

		public String getPrdName() {
			return prdName;
		}

		public void setPrdName(String prdName) {
			this.prdName = prdName;
		}

		public float getPrice() {
			return price;
		}

		public void setPrice(float price) {
			this.price = price;
		}

		void print()
		{
			System.out.print("Id : "+prdId+" Name: "+ prdName+" Price : "+price);
		}
	
}

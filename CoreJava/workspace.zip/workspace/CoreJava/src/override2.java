
public class override2 {
	public static void main(String[] args) {
		parent1 p=new child1();
		System.out.println(p.getx());
		System.out.println(p.x);
	}

}
class parent1
{
	int x=10;
	int getx()
	{
		return(x);
	}
}
class child1 extends parent1
{
	int x=99;
	int getx()
	{
		return(x);
	}
}



public class PermEmp extends employee {
	private float basic;
	private float hra;
	private float pf;
	public float getBasic() {
		return basic;
	}
	public void setBasic(float basic) {
		this.basic = basic;
	}
	public float getHra() {
		return hra;
	}
	public void setHra(float hra) {
		this.hra = hra;
	}
	public float getPf() {
		return pf;
	}
	public void setPf(float pf) {
		this.pf = pf;
	}
	@Override
	void f1x() {
		// TODO Auto-generated method stub
		float totSal=basic+hra-pf;
		System.out.println(totSal);
	}
	

}

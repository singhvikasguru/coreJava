

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class set1 {
	public static void main(String[] args) {
		HashSet<String> h1=new HashSet<>();
		h1.add("Banglore");
		h1.add("Mysore");
		h1.add("Bombay");
		h1.add("Banglore");
		//System.out.println(h1);
		for(String s:h1)
		{
			System.out.println("----"+s+"----");
		}
		
		TreeSet<String> t1=new TreeSet<>();
		t1.add("Banglore");
		t1.add("Mysore");
		t1.add("Bombay");
		t1.add("Banglore");
		System.out.println(t1);
		
		LinkedHashSet<String> lhs=new LinkedHashSet<>();
		lhs.add("Zimbra");
		lhs.add("Banglore");
		lhs.add("Mysore");
		lhs.add("Bombay");
		lhs.add("Banglore");
		System.out.println(lhs);
	}

}

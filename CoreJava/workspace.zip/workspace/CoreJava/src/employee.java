

import java.lang.String;

abstract public class employee {
	private int eId;
	private String nmae;
	public int geteId() {
		return eId;
	}
	public void seteId(int eId) {
		this.eId = eId;
	}
	public String getNmae() {
		return nmae;
	}
	public void setNmae(String nmae) {
		this.nmae = nmae;
	}
	abstract void f1x();

}

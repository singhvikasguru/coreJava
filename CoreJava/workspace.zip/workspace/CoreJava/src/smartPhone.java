
public class smartPhone extends Product {
private String os;
private String ram;
private String brand;
public String getOs() {
	return os;
}
public void setOs(String os) {
	this.os = os;
}
public String getRam() {
	return ram;
}
public void setRam(String ram) {
	this.ram = ram;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}

void print()
{
	super.print();
	System.out.println("OS :"+os+" ,brand :"+brand+" ,ram :"+ram+" Id : "+super.getPrdId());
}
}


public class book extends Product {
	private String grnre;
	private String author;
	public String getGrnre() {
		return grnre;
	}
	public void setGrnre(String grnre) {
		this.grnre = grnre;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	void print()
	{
		super.print();
		System.out.println("Genre : "+grnre+" ,Author : "+author);
	}

}


public class objectMain {
	public static void main(String[] args) {
		Product p1=new Product();
		p1.setPrdId(104);
		p1.setPrdName("Shoes");
		p1.setPrice(10000);
		System.out.println("Id " +p1.getPrdId());
		System.out.println("Name " +p1.getPrdName());
		System.out.println("Price " +p1.getPrice());
				
	}

}

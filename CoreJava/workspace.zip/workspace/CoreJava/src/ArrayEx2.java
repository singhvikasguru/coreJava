
public class ArrayEx2 {
	public static void main(String[] args) {
		
		Product p1=new Product();
		p1.setPrdId(101);
		p1.setPrdName("T Shirt");
		p1.setPrice(1000);
		
		Product p2=new Product();
		p2.setPrdId(102);
		p2.setPrdName("Shirt");
		p2.setPrice(2000);
		
		Product p3=new Product();
		p3.setPrdId(103);
		p3.setPrdName("Jeans");
		p3.setPrice(3000);
		Product pf[]={p1,p2,p3};
		for(Product ele:pf)
		{
			System.out.print(ele.getPrdId()+" , ");
			System.out.print(ele.getPrdName()+" , ");
			System.out.println(ele.getPrice()+" , ");
		}
		smartPhone ph1=new smartPhone();
		ph1.setPrdId(11);
		ph1.setPrdName("Nokia 1600");
		ph1.setPrice(1400);
		ph1.setBrand("Nokia");
		ph1.setOs("OLD");
		ph1.setRam(".1gb");
		System.out.println(ph1.getBrand()+" , "+ph1.getPrdId()+" , "+ph1.getPrdName());
		
		book b1=new book();
		b1.setPrdName("Shiva trilogy");
		b1.setPrdId(1232);
		b1.setAuthor("Amish");
		b1.setPrice(4500);
		System.out.println(b1.getPrdName()+" "+b1.getPrdId()+" "+b1.getAuthor()+" "+b1.getPrice());
	}

}

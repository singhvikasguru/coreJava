

public class abstExm {
	public static void main(String[] args) {
		//new employee();
		PermEmp e1= new PermEmp();
		e1.setBasic(10000);
		e1.seteId(1011);
		e1.setHra(2000);
		e1.setPf(500);
		e1.setNmae("Abcd");
		//e1.f1x();
		calSal(e1);
		
		
		ContEmp em2=new ContEmp();
		em2.seteId(1123);
		em2.setNmae("qwerty");
		em2.setNumDays(123);
		em2.setWages(500);
		//em2.f1x();
		calSal(em2);
		
	}
	static void calSal(employee e)
	{
		e.f1x();
	}

}

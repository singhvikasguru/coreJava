
public class constructor2 {
	public static void main(String[] args) {
		new childx();
		System.out.println("-----------------");
		new childx();
	}
}       
class parentx{
	static {
		System.out.println("Static Parent block");
	}
	{
		System.out.println("Parent block");
	}
	parentx(){
		System.out.println("Parent const");
	}
}
class childx extends parentx{
	static {
		System.out.println("Static Child block");
	}
	{
		System.out.println("Child block");
	}
	childx(){
		System.out.println("child const");
	}
}


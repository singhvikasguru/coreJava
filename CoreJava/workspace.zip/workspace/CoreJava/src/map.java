import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class map {
	public static void main(String[] args) {
		//HashMap<String, String> map1=new HashMap<>();
		TreeMap<String, String> map1=new TreeMap<>();
		map1.put("vns", "Varanasi");
		map1.put("ndls", "New Delhi");
		map1.put("SBC", "Banglore");
		map1.put("CST", "Mumbai");
		System.out.println(map1);
		map1.put("CST", "Mumbai");
		System.out.println(map1);
		System.out.println("-------------------------------------");
		System.out.println(map1.get("CST"));
		
		Set<String> code= map1.keySet();
		for(String k:code)
		{
			System.out.println(k+ ", "+ map1.get(k));
		}
		
		Collection<String> stName=map1.values();
		for(String s:stName)
		{
			System.out.println(s);
		}
		Set<Map.Entry<String, String>> records=map1.entrySet();
		for(Map.Entry<String, String> row:records)
		{
			System.out.println(row.getKey()+"---"+row.getValue());
		}
		
	}

}



import java.lang.String;
import java.lang.System;

public class constructor {
	public static void main(String[] args) {
		//customer c1= new customer();
		System.out.println("-----------------");
		person p1 = new person();
		System.out.println("-----------------");
		pCustomer p2=new pCustomer();
	}

}
class person{
	person()
	{
		System.out.println("Person Constructor");
	}
}
class customer extends person{
	customer(String arg1)
	{
		System.out.println("Customer Constructor");
	}
	
}
class pCustomer extends customer{
	 pCustomer() {
		 super("xyz");
		// TODO Auto-generated constructor stub
	}
}
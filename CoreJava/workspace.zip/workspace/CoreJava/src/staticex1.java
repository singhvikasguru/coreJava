

import java.lang.String;
import java.lang.System;

public class staticex1 {
	public static void main(String[] args) {
		student.setcName("Java");
		student s1= new student();
		s1.setsId(101);
		s1.setName("Asd");
		s1.setGrade(89);
		
		student s2= new student();
		s2.setsId(102);
		s2.setName("fgh");
		s2.setGrade(92);
		
		s1.setcName("Java SE");
		System.out.println(s1.getcName());
		System.out.println(s2.getcName());
		
	}

}


public class interface1 {
	public static void main(String[] args) {
		drive d=getCar("BMW");
		d.acclerator();
	}
	 static drive getCar(String str)
	 {
		 if(str=="BMW")
		 return new BMW();
		 else
			 return new honda();
	 }

}
interface drive{
	void acclerator();
}
class BMW implements drive
{

	@Override
	public void acclerator() {
		// TODO Auto-generated method stub
		System.out.println("BMW start moving ...");
		
	}
	
}
class honda implements drive
{

	@Override
	public void acclerator() {
		// TODO Auto-generated method stub
		System.out.println("Honda car start moving...");
	}
	
}


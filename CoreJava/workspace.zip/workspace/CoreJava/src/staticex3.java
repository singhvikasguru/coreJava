

import java.lang.String;
import java.lang.System;

public class staticex3 {
	int a=10;
	static int b=20;
	public static void main(String[] args) {
		staticex3 obj= new staticex3();
		System.out.println("A: "+obj.a);
		System.out.println("B: "+b);
	}
	void f1()
	{
		System.out.println("A: "+a);
		System.out.println("B: "+b);
	}
	
	static void f2()
	{
		staticex3 obj1=new staticex3();
		System.out.println("A: "+obj1.a);
		System.out.println("B: "+b);
	}
	

}


public class polymorph {
	public static void main(String[] args) {
		book b1=new book();
		b1.setAuthor("JK Rowling");
		b1.setPrdId(11123);
		b1.setPrdName("Harry Potter");
		b1.setGrnre("Friction");
		
		smartPhone ph2=new smartPhone();
		ph2.setBrand("Apple");
		ph2.setOs("Android");
		ph2.setPrdName("Iphone X");
		ph2.setPrdId(12454);
		ph2.setPrice(12342);
		Product cart[]={b1, ph2};
		for(Product p:cart)
		{
			p.print();
			System.out.println("***************");
		}
	}

}

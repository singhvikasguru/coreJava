import java.util.ArrayList;
import java.util.LinkedList;

public class arrlist {
	public static void main(String[] args) {
		ArrayList<String> lst1=new ArrayList<>();
		lst1.add("lntml");
		lst1.add("lntml2");
		long t1=System.currentTimeMillis();
		for(int i=0;i<100000;i++)
		lst1.add(0,"lntml3");
		long t2=System.currentTimeMillis();
		System.out.println(t2-t1);
		
		
		LinkedList<String> lst2=new LinkedList<>();
		lst2.add("light");
		//System.out.println(lst2);
		long t12=System.currentTimeMillis();
		for(int i=0;i<10000;i++)
		lst2.add(0,"lntml3");
		long t22=System.currentTimeMillis();
		System.out.println(t22-t12);
	}

}

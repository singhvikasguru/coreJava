import java.util.Vector;

public class vectorex1 {
	public static void main(String[] args) {
		Vector<String> v1=new Vector<String>();
		System.out.println("Capacity: "+v1.capacity());
		Vector<String> v2=new Vector<>(3);
		System.out.println("Capacity: "+v2.capacity());
		v2.add("Banglore");
		v2.add("Mysore");
		v2.add("Banglore");
		v2.add("Mysore");
		System.out.println(v2);
		System.out.println("Capacity: "+v2.capacity());

		
	}

}

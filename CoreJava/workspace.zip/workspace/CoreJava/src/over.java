
public class over {
	public static void main(String[] args) {
		parent p=new child();
		p.f1();
		p.f2();
		child.f2();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
	}

}
class parent{
	void f1(){
		System.out.println("In parent f1");
	}
	static void f2(){
		System.out.println("In parent f2");
	}
}	
class child extends parent{
	protected void f1(){
		System.out.println("In child f1");
	}
	static void f2(){
		System.out.println("In child f2");
	}
	
}
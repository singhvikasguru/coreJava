public class ContEmp extends employee{
	private float wages;
	private float numDays;
	public float getWages() {
		return wages;
	}
	public void setWages(float wages) {
		this.wages = wages;
	}
	public float getNumDays() {
		return numDays;
	}
	public void setNumDays(float numDays) {
		this.numDays = numDays;
	}
	@Override
	void f1x() {
		// TODO Auto-generated method stub
		float totSal=wages*numDays;
		System.out.println(totSal);
	}
	
	

}

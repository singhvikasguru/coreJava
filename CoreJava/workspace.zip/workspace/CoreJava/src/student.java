

import java.lang.String;

public class student {
	public int sId;
	private String Name;
	static String cName;
	public int grade;
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public static String getcName() {
		return cName;
	}
	public static void setcName(String cName) {
		student.cName = cName;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	

}

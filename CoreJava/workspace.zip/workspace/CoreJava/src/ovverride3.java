
public class ovverride3 {
	public static void main(String[] args) {
		superc s=new subc();
		System.out.println(s.x);
	}

}
class superc
{
	int x;
	int y=5;
	int gety()
	{
		return y+1;
	}
}
class subc extends superc
{
	int gety()
	{
		return y*y;
	}
}

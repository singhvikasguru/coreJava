package com.oracle;

import java.util.ArrayList;
import java.util.List;

public class ProductDao {
	private List<Product> productList=new ArrayList<>();
	{
		productList.add(new Product(991,"JBL headphone", 7000.0f));
		productList.add(new Product(992,"Water Bottle", 200));
		productList.add(new Product(993,"oppo phone", 3000.0f));
		productList.add(new Product(994,"Fast track watch", 5000.0f));
	}
	
	public List<Product> getAllProduct()
	{
		return productList;
	}

}

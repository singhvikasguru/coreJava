package com.oracle;

import java.util.List;
import java.util.ListIterator;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

//import java.awt.MediaTracker;
//import java.awt.PageAttributes.MediaType;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/products")
public class ProductService {
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String testProducts()
	{
		return "<font color=blue size=10> Listing All Products</font>";
	}
	@GET
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public List<Product> getAllProduct()
	{
		return new ProductDao().getAllProduct();
	}
	@Path("/sampleProduct")
	@GET
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Product sampleProduct()
	{
		return new Product(101, "T shirt", 999.23f);
	}
	@Path("/id/{pid}")
	@GET
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Product getProductById(@PathParam("pid")int id)
	{
		ProductDao dao=new ProductDao();
		for(Product p:dao.getAllProduct())
		{
			if(p.getProductId()==id)
				return p;
		}
		return null;
	}
	@POST
	@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public List<Product> addNewProduct(Product p)
	{
		ProductDao dao=new ProductDao();
		List<Product> proList=dao.getAllProduct();
		proList.add(p);
		return proList;
	}
	@DELETE
	@Path("/pid/{pid}")
	//@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public List<Product> delProduct(@PathParam("pid") int pid)
	{
		ProductDao dao=new ProductDao();
		List<Product> proList=dao.getAllProduct();
		ListIterator<Product> itr=proList.listIterator();
		while(itr.hasNext())
		{
			if(itr.next().getProductId()==pid)
			{
				itr.remove();
			}
			
		}
		
		return proList;
	}
}

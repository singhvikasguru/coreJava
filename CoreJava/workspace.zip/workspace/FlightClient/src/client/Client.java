package client;

import java.util.List;

import com.oracle.webservice.Flight;
import com.oracle.webservice.FlightInfoService;
import com.oracle.webservice.FlightInfoServiceService;

public class Client {
	public static void main(String[] args) {
		FlightInfoServiceService flightService=new FlightInfoServiceService();
		FlightInfoService flightInfo=flightService.getFlightInfoServicePort();
		List<Flight> flightList=flightInfo.getAllFlight(); 
		for(Flight f:flightList)
			System.out.println(f.getFlightNo()+"\t"+ f.getFare());
	}

}

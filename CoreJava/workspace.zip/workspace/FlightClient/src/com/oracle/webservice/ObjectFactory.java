
package com.oracle.webservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.oracle.webservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SearchByFlightNoResponse_QNAME = new QName("http://webservice.oracle.com/", "searchByFlightNoResponse");
    private final static QName _GetAllFlightResponse_QNAME = new QName("http://webservice.oracle.com/", "getAllFlightResponse");
    private final static QName _GetAllFlight_QNAME = new QName("http://webservice.oracle.com/", "getAllFlight");
    private final static QName _SearchByFlightNo_QNAME = new QName("http://webservice.oracle.com/", "searchByFlightNo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.oracle.webservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SearchByFlightNo }
     * 
     */
    public SearchByFlightNo createSearchByFlightNo() {
        return new SearchByFlightNo();
    }

    /**
     * Create an instance of {@link GetAllFlight }
     * 
     */
    public GetAllFlight createGetAllFlight() {
        return new GetAllFlight();
    }

    /**
     * Create an instance of {@link GetAllFlightResponse }
     * 
     */
    public GetAllFlightResponse createGetAllFlightResponse() {
        return new GetAllFlightResponse();
    }

    /**
     * Create an instance of {@link SearchByFlightNoResponse }
     * 
     */
    public SearchByFlightNoResponse createSearchByFlightNoResponse() {
        return new SearchByFlightNoResponse();
    }

    /**
     * Create an instance of {@link Flight }
     * 
     */
    public Flight createFlight() {
        return new Flight();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchByFlightNoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.oracle.com/", name = "searchByFlightNoResponse")
    public JAXBElement<SearchByFlightNoResponse> createSearchByFlightNoResponse(SearchByFlightNoResponse value) {
        return new JAXBElement<SearchByFlightNoResponse>(_SearchByFlightNoResponse_QNAME, SearchByFlightNoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllFlightResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.oracle.com/", name = "getAllFlightResponse")
    public JAXBElement<GetAllFlightResponse> createGetAllFlightResponse(GetAllFlightResponse value) {
        return new JAXBElement<GetAllFlightResponse>(_GetAllFlightResponse_QNAME, GetAllFlightResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllFlight }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.oracle.com/", name = "getAllFlight")
    public JAXBElement<GetAllFlight> createGetAllFlight(GetAllFlight value) {
        return new JAXBElement<GetAllFlight>(_GetAllFlight_QNAME, GetAllFlight.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchByFlightNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.oracle.com/", name = "searchByFlightNo")
    public JAXBElement<SearchByFlightNo> createSearchByFlightNo(SearchByFlightNo value) {
        return new JAXBElement<SearchByFlightNo>(_SearchByFlightNo_QNAME, SearchByFlightNo.class, null, value);
    }

}

@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.oracle.com/")
package com.oracle.webservice;

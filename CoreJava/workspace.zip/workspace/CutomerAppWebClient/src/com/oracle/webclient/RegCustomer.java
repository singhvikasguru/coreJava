package com.oracle.webclient;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oracle.ejb.CustomerFacadeBean;
import com.oracle.ejb.CustomerFacadeBeanRemote;
import com.oracle.entity.Customer;

@WebServlet("/RegCustomer")
public class RegCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public RegCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }
    @EJB //DI(dependence injection) replacement of service locator
    private CustomerFacadeBeanRemote remote;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int cid=Integer.parseInt(request.getParameter("ID"));
		String cname=request.getParameter("Customer");
		String email=request.getParameter("email");
		Customer c=new Customer();
		c.setId(cid);
		c.setCustName(cname);
		c.setEmail(email);
		remote.addCustomer(c);
		response.getWriter().print(" Customer added ..");
	}

	

}

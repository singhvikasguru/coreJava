package com.oracle.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.oracle.entity.Employee;

public class EmployeeDao {
	private EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAUnit");
	public void addEmploye(Employee e)
	{
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(e);
		em.getTransaction().commit();
		System.out.println("Done...");
	}
	public Employee readEmpById(int empId)
	{
		EntityManager em=emf.createEntityManager();
		Employee e=em.find(Employee.class, empId);
		return e;
	}
	public List<Employee> readAllEmps()
	{
		EntityManager em=emf.createEntityManager();
		String jpql="select e from Employee e where e.salary<=  :sal";
		Query query=em.createQuery(jpql);
		query.setParameter("sal", 10000000f);
		List<Employee> empList=query.getResultList();
		return empList;
	}

}

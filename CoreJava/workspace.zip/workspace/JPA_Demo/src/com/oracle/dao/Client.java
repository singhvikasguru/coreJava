package com.oracle.dao;

import java.util.List;
import java.util.Scanner;

import com.oracle.entity.Employee;

public class Client {
	public static void main(String[] args) {
		/*Employee e=new Employee();
		e.setEmpId(1014);
		e.setEmpName("Vikas Singh");
		e.setSalary(2000000.0f);
		EmployeeDao dao=new EmployeeDao();
		dao.addEmploye(e);*/
		EmployeeDao dao=new EmployeeDao();
		System.out.println("Enter id....");
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		List<Employee> e=dao.readAllEmps();
		for(Employee ee:e)
		{
			System.out.println("Id: = "+ee.getEmpId()+" , "+ee.getEmpName()+" , "+ee.getSalary());
		}
		/*if(e!=null)
		{
			System.out.println("Id: = "+e.getEmpId()+" , "+e.getEmpName()+" , "+e.getSalary());
		}
		else
			System.out.println("Not Found");*/
			
	}

}

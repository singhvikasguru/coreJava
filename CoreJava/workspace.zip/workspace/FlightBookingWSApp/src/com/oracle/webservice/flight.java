package com.oracle.webservice;

public class flight {
	private String flightNo;
	private String from;
	private String to;
	private int fare;
	
	public flight() {
		// TODO Auto-generated constructor stub
	}
	
	public flight(String flightNo, String from, String to, int i) {
		super();
		this.flightNo = flightNo;
		this.from = from;
		this.to = to;
		this.fare = i;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	

}

package com.oracle.webservice;

import java.util.List;

import javax.jws.WebService;

@WebService// exposing to outside world
public class FlightInfoService {
	flightDao dao= null;
	
	public flight searchByFlightNo(String flightNo)
	{
		dao=new flightDao();
		return dao.SearchByFlightNo(flightNo);
	}
	public List<flight> getAllFlight()
	{
		return dao.getAllFlight();
	}

}

package com.oracle.webservice;

import java.util.ArrayList;
import java.util.List;

public class flightDao {
private List<flight> flightList=new ArrayList<>();
{
	flightList.add(new flight("Ae101", "Banglore", "Mumbai", 5000));
	flightList.add(new flight("Jet123", "Banglore", "Mumbai", 4000));
	flightList.add(new flight("AirIndia231", "Banglore", "Mumbai", 5500));
}
public flight SearchByFlightNo(String flightNo)
{
	for(flight f:flightList)
	{
		if(f.getFlightNo().equals(flightNo))
			return f;
		
	}
	return null;
	
}
public List<flight> getAllFlight()
{
	return flightList;
}
}

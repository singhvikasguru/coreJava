package com.oracle.ejb;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.oracle.entity.Customer;

@Stateless
public class CustomerFacadeBean implements CustomerFacadeBeanRemote {
    @PersistenceContext
	private EntityManager em;//EntityManger obj created by EJB container and injected here...

	@Override
	public void addCustomer(Customer cust) {
		// TODO Auto-generated method stub
		em.persist(cust);
		
	}

	@Override
	public Customer readCustomer(int custId) {
		// TODO Auto-generated method stub
		return em.find(Customer.class, custId);
	}
   

}

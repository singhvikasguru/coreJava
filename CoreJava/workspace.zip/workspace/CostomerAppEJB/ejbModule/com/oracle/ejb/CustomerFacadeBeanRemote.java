package com.oracle.ejb;

import javax.ejb.Remote;

import com.oracle.entity.Customer;

@Remote
public interface CustomerFacadeBeanRemote {
	void addCustomer(Customer cust);
    Customer readCustomer(int custId);
}
